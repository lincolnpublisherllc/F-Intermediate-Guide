idris2 Main.idr
