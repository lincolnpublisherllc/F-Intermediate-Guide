idris2 Main.idr
At the Main> prompt:
Main> :t main
main : IO ()
Main> :exec main
