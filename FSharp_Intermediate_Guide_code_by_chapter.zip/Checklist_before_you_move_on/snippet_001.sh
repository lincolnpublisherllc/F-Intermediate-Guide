idris2 --version prints a version
