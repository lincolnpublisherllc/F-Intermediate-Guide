idris2 --build adder.ipkg
idris2 --exec main adder.ipkg
