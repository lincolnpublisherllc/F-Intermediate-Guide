idris2 --build hello.ipkg
idris2 --exec main hello.ipkg
