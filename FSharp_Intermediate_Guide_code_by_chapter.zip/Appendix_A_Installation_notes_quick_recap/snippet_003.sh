idris2 --version
