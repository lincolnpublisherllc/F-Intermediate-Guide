scoop install idris2
