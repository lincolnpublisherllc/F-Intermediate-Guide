idris2
Main> :?         -- help
Main> :q         -- quit
