choco install idris2 -y
