idris2 --version
idris2 --help
