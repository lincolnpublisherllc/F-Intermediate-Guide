iwr -useb get.scoop.sh | iex
scoop install idris2
