idris2 Echo.idr -x main
