sudo pacman -S idris2
Option D. Build from source (works on most distros)
sudo apt install git make gcc g++ libgmp-dev chezscheme   # adapt package names for your distro
git clone https://github.com/idris-lang/Idris2.git
