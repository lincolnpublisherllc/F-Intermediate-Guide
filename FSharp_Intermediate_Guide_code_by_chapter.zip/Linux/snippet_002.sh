sudo dnf install idris2
