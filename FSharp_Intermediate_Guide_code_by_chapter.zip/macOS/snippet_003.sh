brew install chezscheme gmp coreutils
git clone https://github.com/idris-lang/Idris2.git
