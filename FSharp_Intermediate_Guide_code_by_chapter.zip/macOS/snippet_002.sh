brew update
brew install idris2
