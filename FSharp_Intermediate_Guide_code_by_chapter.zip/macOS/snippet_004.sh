make bootstrap SCHEME=chez
sudo make install
